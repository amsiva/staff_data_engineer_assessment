import unittest
import sys
from pyspark.sql import SparkSession



class ClinicalDataTests(unittest.TestCase):

	
	@classmethod
	def setUpClass(cls):
		spark=SparkSession.builder().master("local[3]").appName("clinicaldatatesting.com").getOrCreate()  
		cls.spark=spark
		cls.json_parameter_file=sys.argv[1]
		with open(cls.json_parameter_file) as jsonfile:
		#the parameters are palced as json file and calling the json file location
			js = json.load(jsonfile)
		self.clinical_file_path=js['parameters']['clinical_file_path']
		self.provider_file_path=js['parameters']['provider_file_path']
		self.stage_clinical_table=js['parameters']['stage_clinical_table']
		self.stage_provider_table=js['parameters']['stage_provider_table']
		self.clinical_title_table=js['parameters']['clinical_title_table']
		self.unique_NPI_without_hyphen=js['parameters']['unique_NPI_without_hyphen']
			
		
	
	def test_stage_clinical_data(self):
		print ("Test case 1 : validation of count between clinical source and stage clinical table")
		source=spark.read.option("header", True).csv(f'{self.clinical_file_path}').count()[0][0]
		target=spark.table(f"{self.stage_clinical_table}").count()[0][0]
		self.assertEqual(source,target)
		
	def test_stage_provider_data(self):
		print ("Test case 2 : validation of count between provider source and stage provider table")
		source=spark.read.option("header", True).csv(f'{self.provider_file_path}').count()[0][0]
		target=spark.table(f"{self.stage_provider_table}").count()[0][0]
		self.assertEqual(source,target)

	def test_distinct_clinical_title(self):
		print ("Test case 3 : validation of distinct count between clinical source and clinical_title table")
		source=spark.read.option("header", True).csv(f'{self.clinical_file_path}').select('title').countDistinct()[0][0]
		target=spark.table(f"{self.clinical_title_table}").count()[0][0]
		self.assertEqual(source,target)	
		
	def test_hypen_NPIs(self):
		print ("Test case 4 : validation of distinct count between clinical source and clinical_title table")
		expected=0
		target=spark.table(f"{self.unique_NPI_without_hyphen}").filter("npi_without_hyphen like '%-%'").count()[0][0]
		self.assertEqual(target,expected)		
		
    
	@classmethod
	def tearDownClass(cls):
		cls.spark.stop()
		
if __name__ == '__main__':
	unittest.main()		

	
		