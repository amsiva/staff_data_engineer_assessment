
import sys
import json
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

spark = SparkSession.builder().master("local[1]").appName("clinicaldata.com").getOrCreate()  






if __name__ == '__main__':

	json_parameter_file=sys.argv[1]
    
    try:
    
        with open(json_parameter_file) as jsonfile: #the parameters are palced as json file and calling the json file location
			js = json.load(jsonfile)  
               
		all_parameters=js['parameters']
		globals().update(all_parameters)

		#Reading the clinical nd provider data 
		clinician_data=spark.read.option("header", True).csv(f'{clinical_file_path}')
		providers_data=spark.read.option("header", True).csv(f'{provider_file_path}')	


		#staging a copy of data to in memory

		clinician_data.write.mode('overwrite').format('csv').saveAsTable(f'{stage_clinical_table}')
		providers_data.write.mode('overwrite').format('csv').saveAsTable(f'{stage_provider_table}')


		#reading back staging data for further derivations

		stg_clinician=spark.table(f'{stage_clinical_table}')
		stg_providers=spark.table(f'{stage_provider_table}')

		#finding the unique title from clinical and loading into the clinical title table as per the parameter from json

		clinical_title=stg_clinician.select(stg_clinician.title).distinct()
		clinical_title.write.mode('overwrite').format('csv').saveAsTable(f'{clinical_title_table}')

		#get the npi after '-' from both clinical and providers data and get the unique numbers and store in the table 

		clinical_NPI_without_hyphen=stg_clinician.select(split(stg_clinician.NPI,'-').getItem(1).alias('npi_without_hyphen')).distinct()
		providers_NPI_without_hyphen=stg_providers.select(split(stg_providers.NPI,'-').getItem(1).alias('npi_without_hyphen')).distinct()
		NPI_without_hyphen=clinical_NPI_without_hyphen.union(providers_NPI_without_hyphen)
		NPI_without_hyphen.write.mode('overwrite').format('csv').saveAsTable(f'{unique_NPI_without_hyphen}')


		#getting the unique NPI and load into the parameter table


		clinical_NPI=stg_clinician.select(stg_clinician.NPI.alias('unique_npi')).distinct()
		providers_NPI=stg_providers.select(stg_providers.NPI.alias('unique_npi')).distinct()
		NPI_with_hyphen=clinical_NPI.union(providers_NPI)
		NPI_with_hyphen.write.mode('overwrite').format('csv').saveAsTable(f'{NPI_table}')



	except Exception as e: 
		print(f"Please check the error : {e}" )
		spark.stop()