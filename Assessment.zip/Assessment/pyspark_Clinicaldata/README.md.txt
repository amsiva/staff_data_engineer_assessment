The document gives idea about how we have to run the spark job 

1. Provide the input parameters into the JSON file
2. run the clinical_data.py in spark with argument as the file path of the json file
3. Run the unit test case ClinicalDataTests (for unit test also we need to pass the json path parameters)


