create table testdb.cliniciandata (
id NUMBER ,
first_name VARCHAR2(100),
last_name VARCHAR2(100),
date_of_birth date,
gender VARCHAR2(100),
email VARCHAR2(100),
PRIMARY KEY (id)
);

CREATE INDEX clinician_last_name_i 
ON testdb.cliniciandata(last_name);


