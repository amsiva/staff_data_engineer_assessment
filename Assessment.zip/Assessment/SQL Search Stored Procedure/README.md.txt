This Readme file provides the guidance to follow the steps

1. First run the dbca file to create a new database called testdb
2. Execute the create_table  statement to create the test table for testing
3. Insert the new records using available document
4. Execute the search_store_procedure to find the exact match, Possible match or no match.