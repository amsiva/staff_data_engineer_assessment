insert into testdb.cliniciandata values (1, "Ashwin", "Ravichandran", to_date('1990-01-01','YYYY-MM-DD'), "Male", "ashwin.ravichandran@gmail.com");
insert into testdb.cliniciandata values (2, "Dhoni", "Mahendra", to_date('1992-01-01','YYYY-MM-DD'), "Male", "dhoni.Mahendra@gmail.com");
insert into testdb.cliniciandata values (3, "Virat", "kohli", to_date('1995-01-01','YYYY-MM-DD'), "Male", "kohli.virat@gmail.com");
insert into testdb.cliniciandata values (4, "Yuvraj", "Singh", to_date('1993-01-01','YYYY-MM-DD'), "Male", "Yuvraj.singh@gmail.com");
commit;