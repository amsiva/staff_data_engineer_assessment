set serveroutput on;

CREATE OR REPLACE PROCEDURE testdb.findingmatch
	(
	input_first_name IN VARCHAR2,
	input_last_name IN VARCHAR2,
	input_email IN VARCHAR2,
	input_date_of_birth IN date,
	input_gender IN VARCHAR2,
	id OUT NUMBER,
	decision OUT VARCHAR2,
	score OUT NUMBER
	
	)
AS	
BEGIN
IF input_first_name is not null and input_last_name is not null and input_email is not null and input_date_of_birth is not null and input_gender is not null then 
	id := NULL;
	decision := "No Match";
	Score := 0;
	select id into output_id, 'Exact' into decision, 100 into score from testdb.cliniciandata where first_name=input_first_name and last_name=input_last_name and email=input_email 
	and date_of_birth=input_date_of_birth and gender=input_gender;

ELSIF input_first_name is not null and input_last_name is not null and input_email is not null and (input_date_of_birth is not null or input_gender is not null) then 
	id := NULL;
	decision := "Unable to Match";
	score := 0;
	select id into output_id, 'Possible' into decision, 50 into score from testdb.cliniciandata where first_name=input_first_name and last_name=input_last_name and email=input_email 
	and nvl(date_of_birth,to_date('2099-12-31','yyyy-mm-dd'))=nvl(input_date_of_birth,to_date('2099-12-31','yyyy-mm-dd')) and nvl(gender,'XYZ')=nvl(input_gender,'XYZ');
ELSE 
	id := NULL;
	decision := "Unable to Match";
	score := 0;
	
END IF;

	
DBMS_OUTPUT.PUT_LINE('id = ' || TO_CHAR(id) || ' - decision = '||decision|| " score = " ||TO_CHAR(decision))

END;